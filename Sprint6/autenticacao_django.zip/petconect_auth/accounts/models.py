"""
accounts/models.py
Modelo customizado de usuário para o PetConect.

Estende AbstractBaseUser para suportar três tipos de perfil:
  - ADOTANTE   : pessoa que quer adotar um animal
  - RESGATADOR : protetor independente
  - ONG        : organização formal com CNPJ
"""
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.db import models
from django.utils import timezone


class UsuarioPetConectManager(BaseUserManager):
    """Manager customizado: usa e-mail como identificador único."""

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('O e-mail é obrigatório.')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if not extra_fields.get('is_staff'):
            raise ValueError('Superuser precisa ter is_staff=True.')
        if not extra_fields.get('is_superuser'):
            raise ValueError('Superuser precisa ter is_superuser=True.')

        return self.create_user(email, password, **extra_fields)


class UsuarioPetConect(AbstractBaseUser, PermissionsMixin):
    """
    Usuário customizado do PetConect.

    - LOGIN por e-mail (não por username)
    - Três tipos de perfil controlam o que o usuário pode fazer na plataforma
    """

    class TipoPerfil(models.TextChoices):
        ADOTANTE   = 'adotante',   'Adotante'
        RESGATADOR = 'resgatador', 'Resgatador independente'
        ONG        = 'ong',        'ONG / Abrigo'

    # ---- campos básicos ----
    email       = models.EmailField('E-mail', unique=True)
    nome        = models.CharField('Nome completo / Razão social', max_length=150)
    telefone    = models.CharField('Telefone', max_length=20, blank=True)
    cidade      = models.CharField('Cidade', max_length=100, blank=True)
    estado      = models.CharField('Estado (UF)', max_length=2, blank=True)
    bio         = models.TextField('Sobre você / a ONG', blank=True)
    foto_perfil = models.ImageField('Foto de perfil', upload_to='perfis/', blank=True, null=True)

    # ---- tipo de perfil ----
    tipo_perfil = models.CharField(
        'Tipo de perfil',
        max_length=12,
        choices=TipoPerfil.choices,
        default=TipoPerfil.ADOTANTE,
    )

    # ---- campos exclusivos para ONG / Resgatador ----
    cnpj            = models.CharField('CNPJ', max_length=18, blank=True)
    nome_organizacao = models.CharField('Nome da organização', max_length=200, blank=True)

    # ---- campos de controle do Django ----
    is_active    = models.BooleanField('Ativo', default=True)
    is_staff     = models.BooleanField('Admin', default=False)
    date_joined  = models.DateTimeField('Data de cadastro', default=timezone.now)

    # ---- verificação de e-mail ----
    email_verificado = models.BooleanField('E-mail verificado', default=False)

    objects = UsuarioPetConectManager()

    USERNAME_FIELD  = 'email'       # campo usado para login
    REQUIRED_FIELDS = ['nome']      # campos pedidos no createsuperuser

    class Meta:
        verbose_name        = 'Usuário PetConect'
        verbose_name_plural = 'Usuários PetConect'

    def __str__(self):
        return f'{self.nome} <{self.email}>'

    # ---- helpers de tipo ----
    @property
    def is_adotante(self):
        return self.tipo_perfil == self.TipoPerfil.ADOTANTE

    @property
    def is_resgatador(self):
        return self.tipo_perfil == self.TipoPerfil.RESGATADOR

    @property
    def is_ong(self):
        return self.tipo_perfil == self.TipoPerfil.ONG

    @property
    def pode_cadastrar_animal(self):
        """Somente resgatadores e ONGs cadastram animais."""
        return self.tipo_perfil in (self.TipoPerfil.RESGATADOR, self.TipoPerfil.ONG)

    def get_nome_exibicao(self):
        """Retorna nome da organização se disponível, senão o nome pessoal."""
        return self.nome_organizacao or self.nome
