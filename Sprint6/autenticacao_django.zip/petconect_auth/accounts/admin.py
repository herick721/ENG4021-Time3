"""
accounts/admin.py
Registro do modelo customizado no Django Admin.
"""
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import UsuarioPetConect


@admin.register(UsuarioPetConect)
class UsuarioPetConectAdmin(UserAdmin):
    """
    Admin customizado que exibe os campos específicos do PetConect
    (tipo_perfil, telefone, cidade, etc.)
    """
    model = UsuarioPetConect

    # Colunas visíveis na listagem
    list_display  = ('email', 'nome', 'tipo_perfil', 'cidade', 'is_active', 'date_joined')
    list_filter   = ('tipo_perfil', 'is_active', 'is_staff', 'estado')
    search_fields = ('email', 'nome', 'nome_organizacao', 'cidade')
    ordering      = ('-date_joined',)

    # Campos exibidos no formulário de edição
    fieldsets = (
        ('Credenciais', {
            'fields': ('email', 'password')
        }),
        ('Dados pessoais', {
            'fields': ('nome', 'telefone', 'cidade', 'estado', 'bio', 'foto_perfil')
        }),
        ('Tipo de perfil', {
            'fields': ('tipo_perfil', 'cnpj', 'nome_organizacao')
        }),
        ('Permissões', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
            'classes': ('collapse',),
        }),
        ('Datas', {
            'fields': ('date_joined', 'last_login'),
            'classes': ('collapse',),
        }),
    )

    # Campos no formulário de criação de novo usuário
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'nome', 'tipo_perfil', 'password1', 'password2'),
        }),
    )

    # Django Admin usa 'username' por padrão; precisamos substituir pelo email
    USERNAME_FIELD_DISPLAY = 'email'
