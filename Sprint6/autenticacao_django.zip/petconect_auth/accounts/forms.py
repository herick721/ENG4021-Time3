"""
accounts/forms.py
Formulários de autenticação do PetConect.
"""
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.password_validation import validate_password
from .models import UsuarioPetConect


# ------------------------------------------------------------------ #
#  FORMULÁRIO DE LOGIN                                                 #
# ------------------------------------------------------------------ #
class LoginForm(AuthenticationForm):
    """
    Estende o AuthenticationForm padrão do Django.
    Customiza os widgets e mensagens de erro para português.
    """
    username = forms.EmailField(
        label='E-mail',
        widget=forms.EmailInput(attrs={
            'placeholder': 'seu@email.com',
            'autofocus': True,
            'class': 'form-input',
        })
    )
    password = forms.CharField(
        label='Senha',
        widget=forms.PasswordInput(attrs={
            'placeholder': '••••••••',
            'class': 'form-input',
        })
    )
    remember_me = forms.BooleanField(
        label='Manter conectado',
        required=False,
    )

    error_messages = {
        'invalid_login': 'E-mail ou senha incorretos. Verifique seus dados e tente novamente.',
        'inactive': 'Esta conta está desativada.',
    }


# ------------------------------------------------------------------ #
#  FORMULÁRIO DE CADASTRO                                              #
# ------------------------------------------------------------------ #
class CadastroForm(forms.ModelForm):
    """
    Cadastro novo usuário.
    Campos variam visualmente por tipo de perfil (controlado via JS no template),
    mas a validação server-side verifica os campos obrigatórios por tipo.
    """
    password1 = forms.CharField(
        label='Senha',
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Mínimo 8 caracteres',
            'class': 'form-input',
        })
    )
    password2 = forms.CharField(
        label='Confirmar senha',
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Repita a senha',
            'class': 'form-input',
        })
    )

    class Meta:
        model  = UsuarioPetConect
        fields = [
            'nome', 'email', 'telefone',
            'cidade', 'estado',
            'tipo_perfil',
            'cnpj', 'nome_organizacao',
        ]
        widgets = {
            'nome':             forms.TextInput(attrs={'placeholder': 'Seu nome completo', 'class': 'form-input'}),
            'email':            forms.EmailInput(attrs={'placeholder': 'seu@email.com',    'class': 'form-input'}),
            'telefone':         forms.TextInput(attrs={'placeholder': '(21) 99999-9999',   'class': 'form-input'}),
            'cidade':           forms.TextInput(attrs={'placeholder': 'Ex: Rio de Janeiro','class': 'form-input'}),
            'estado':           forms.TextInput(attrs={'placeholder': 'Ex: RJ',            'class': 'form-input', 'maxlength': '2'}),
            'tipo_perfil':      forms.Select(attrs={'class': 'form-input'}),
            'cnpj':             forms.TextInput(attrs={'placeholder': '00.000.000/0001-00','class': 'form-input'}),
            'nome_organizacao': forms.TextInput(attrs={'placeholder': 'Nome da ONG / organização', 'class': 'form-input'}),
        }

    # ---- validação da senha ----
    def clean_password1(self):
        password1 = self.cleaned_data.get('password1')
        if password1:
            validate_password(password1)
        return password1

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')
        tipo = cleaned_data.get('tipo_perfil')

        # Senhas coincidem?
        if password1 and password2 and password1 != password2:
            self.add_error('password2', 'As senhas não coincidem.')

        # Campos obrigatórios para ONG
        if tipo == UsuarioPetConect.TipoPerfil.ONG:
            if not cleaned_data.get('nome_organizacao'):
                self.add_error('nome_organizacao', 'O nome da organização é obrigatório para ONGs.')

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        if commit:
            user.save()
        return user


# ------------------------------------------------------------------ #
#  FORMULÁRIO DE EDIÇÃO DE PERFIL                                      #
# ------------------------------------------------------------------ #
class EditarPerfilForm(forms.ModelForm):
    """Permite ao usuário atualizar seus dados básicos após o login."""

    class Meta:
        model  = UsuarioPetConect
        fields = ['nome', 'telefone', 'cidade', 'estado', 'bio', 'foto_perfil', 'nome_organizacao']
        widgets = {
            'nome':             forms.TextInput(attrs={'class': 'form-input'}),
            'telefone':         forms.TextInput(attrs={'class': 'form-input'}),
            'cidade':           forms.TextInput(attrs={'class': 'form-input'}),
            'estado':           forms.TextInput(attrs={'class': 'form-input', 'maxlength': '2'}),
            'bio':              forms.Textarea(attrs={'class': 'form-input', 'rows': 4}),
            'nome_organizacao': forms.TextInput(attrs={'class': 'form-input'}),
        }
