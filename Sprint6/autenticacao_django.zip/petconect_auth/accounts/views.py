"""
accounts/views.py
Views de autenticação do PetConect.

Fluxo completo:
  GET  /login/        → exibe formulário de login
  POST /login/        → autentica e redireciona por tipo de perfil
  GET  /logout/       → encerra sessão e redireciona para login
  GET  /cadastro/     → exibe formulário de cadastro
  POST /cadastro/     → cria conta e faz login automático
  GET  /dashboard/    → painel pós-login (requer autenticação)
  GET  /perfil/       → exibe / edita dados do usuário logado
"""
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.http import require_http_methods

from .forms import LoginForm, CadastroForm, EditarPerfilForm
from .models import UsuarioPetConect


# ------------------------------------------------------------------ #
#  HELPER: destino pós-login por tipo de perfil                        #
# ------------------------------------------------------------------ #
def _redirect_por_perfil(user):
    """Retorna a URL de destino de acordo com o tipo de perfil do usuário."""
    if user.is_adotante:
        return '/dashboard/'
    elif user.pode_cadastrar_animal:          # resgatador ou ONG
        return '/dashboard/ong/'
    return '/dashboard/'


# ------------------------------------------------------------------ #
#  LOGIN                                                               #
# ------------------------------------------------------------------ #
@require_http_methods(['GET', 'POST'])
def login_view(request):
    """
    GET  → renderiza o formulário
    POST → valida credenciais, cria sessão e redireciona

    Controle de sessão:
      - Se "lembrar" marcado → cookie dura SESSION_COOKIE_AGE (settings)
      - Se não marcado      → sessão expira ao fechar o navegador
    """
    # Usuário já autenticado não precisa ver o login
    if request.user.is_authenticated:
        return redirect(_redirect_por_perfil(request.user))

    form = LoginForm(request, data=request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            user = form.get_user()

            # Controla duração da sessão pelo checkbox "lembrar"
            remember = form.cleaned_data.get('remember_me')
            if not remember:
                request.session.set_expiry(0)     # expira ao fechar browser
            else:
                request.session.set_expiry(None)  # usa SESSION_COOKIE_AGE

            login(request, user)

            messages.success(request, f'Bem-vindo(a) de volta, {user.get_nome_exibicao()}! 🐾')

            # Respeita parâmetro ?next= ou redireciona por perfil
            next_url = request.GET.get('next') or _redirect_por_perfil(user)
            return redirect(next_url)

        else:
            messages.error(request, 'E-mail ou senha incorretos. Tente novamente.')

    return render(request, 'accounts/login.html', {'form': form})


# ------------------------------------------------------------------ #
#  LOGOUT                                                              #
# ------------------------------------------------------------------ #
@require_http_methods(['GET', 'POST'])
def logout_view(request):
    """
    Encerra a sessão e redireciona para login.
    Aceita GET e POST para facilitar link direto no navbar.
    """
    nome = request.user.get_nome_exibicao() if request.user.is_authenticated else ''
    logout(request)
    if nome:
        messages.info(request, f'Até logo, {nome}! Sessão encerrada com sucesso.')
    return redirect('login')


# ------------------------------------------------------------------ #
#  CADASTRO                                                            #
# ------------------------------------------------------------------ #
@require_http_methods(['GET', 'POST'])
def cadastro_view(request):
    """
    Cadastro de novo usuário.
    Após cadastro bem-sucedido: login automático + redirect para dashboard.
    """
    if request.user.is_authenticated:
        return redirect(_redirect_por_perfil(request.user))

    form = CadastroForm(request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            user = form.save()

            # Login automático após cadastro
            login(request, user)

            messages.success(
                request,
                f'Conta criada com sucesso! Bem-vindo(a) ao PetConect, {user.get_nome_exibicao()}! 🐾'
            )
            return redirect(_redirect_por_perfil(user))

    return render(request, 'accounts/cadastro.html', {'form': form})


# ------------------------------------------------------------------ #
#  DASHBOARD — ADOTANTE                                                #
# ------------------------------------------------------------------ #
@login_required
def dashboard_view(request):
    """
    Painel principal do adotante.
    @login_required redireciona para LOGIN_URL se não autenticado.
    """
    context = {
        'usuario': request.user,
    }
    return render(request, 'accounts/dashboard.html', context)


# ------------------------------------------------------------------ #
#  DASHBOARD — ONG / RESGATADOR                                        #
# ------------------------------------------------------------------ #
@login_required
def dashboard_ong_view(request):
    """
    Painel de gerenciamento para resgatadores e ONGs.
    Usuários sem permissão são redirecionados para o dashboard padrão.
    """
    if not request.user.pode_cadastrar_animal:
        messages.warning(request, 'Acesso restrito a resgatadores e ONGs.')
        return redirect('dashboard')

    context = {
        'usuario': request.user,
    }
    return render(request, 'accounts/dashboard_ong.html', context)


# ------------------------------------------------------------------ #
#  PERFIL DO USUÁRIO                                                   #
# ------------------------------------------------------------------ #
@login_required
@require_http_methods(['GET', 'POST'])
def perfil_view(request):
    """
    Exibe e permite edição dos dados do usuário logado.
    """
    form = EditarPerfilForm(
        request.POST or None,
        request.FILES or None,
        instance=request.user,
    )

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, 'Perfil atualizado com sucesso!')
            return redirect('perfil')

    context = {
        'usuario': request.user,
        'form': form,
    }
    return render(request, 'accounts/perfil.html', context)
