"""
accounts/urls.py
Rotas do sistema de autenticação do PetConect.
"""
from django.urls import path
from . import views

urlpatterns = [
    # Autenticação
    path('login/',    views.login_view,    name='login'),
    path('logout/',   views.logout_view,   name='logout'),
    path('cadastro/', views.cadastro_view, name='cadastro'),

    # Dashboards (protegidos por @login_required)
    path('dashboard/',      views.dashboard_view,     name='dashboard'),
    path('dashboard/ong/',  views.dashboard_ong_view, name='dashboard_ong'),

    # Perfil do usuário
    path('perfil/', views.perfil_view, name='perfil'),

    # Redireciona raiz para login
    path('', lambda req: __import__('django.shortcuts', fromlist=['redirect']).redirect('login')),
]
