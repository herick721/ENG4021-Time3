# 🔐 PetConect — Sistema de Autenticação Django

App Django com autenticação completa: login, logout, cadastro com 3 tipos de perfil, controle de sessão e proteção de rotas.

---

## 📁 Estrutura do projeto

```
petconect_auth/
├── manage.py
├── petconect_auth/          ← configurações do projeto
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
└── accounts/                ← app de autenticação
    ├── models.py            ← UsuarioPetConect (modelo customizado)
    ├── forms.py             ← LoginForm, CadastroForm, EditarPerfilForm
    ├── views.py             ← login_view, logout_view, cadastro_view, dashboard_view, perfil_view
    ├── urls.py              ← rotas do app
    ├── admin.py             ← painel admin customizado
    └── templates/accounts/
        ├── base.html
        ├── login.html
        ├── cadastro.html
        ├── dashboard.html       ← dashboard adotante
        └── dashboard_ong.html   ← dashboard ONG/resgatador
```

---

## 🚀 Como rodar

### 1. Instalar dependências

```bash
pip install django pillow
```

> `pillow` é necessário para o campo `ImageField` (foto de perfil).

### 2. Criar e aplicar as migrations

```bash
cd petconect_auth
python manage.py makemigrations accounts
python manage.py migrate
```

### 3. Criar um superusuário (para acessar o admin)

```bash
python manage.py createsuperuser
# informe: email, nome e senha
```

### 4. Rodar o servidor

```bash
python manage.py runserver
```

### 5. Acessar no navegador

| URL | Descrição |
|---|---|
| `http://localhost:8000/login/` | Tela de login |
| `http://localhost:8000/cadastro/` | Tela de cadastro |
| `http://localhost:8000/dashboard/` | Painel do adotante (requer login) |
| `http://localhost:8000/dashboard/ong/` | Painel ONG/resgatador (requer login + tipo correto) |
| `http://localhost:8000/perfil/` | Editar perfil (requer login) |
| `http://localhost:8000/logout/` | Encerrar sessão |
| `http://localhost:8000/admin/` | Django Admin |

---

## 🧠 Decisões técnicas importantes

### Modelo customizado (`AUTH_USER_MODEL`)
- Login por **e-mail** (não por username), usando `AbstractBaseUser`
- Três tipos de perfil: `adotante`, `resgatador`, `ong`
- Campos extras para ONG: `nome_organizacao`, `cnpj`
- Propriedades helpers: `is_adotante`, `is_ong`, `pode_cadastrar_animal`

### Controle de sessão
- Checkbox "Manter conectado": se marcado, sessão dura `SESSION_COOKIE_AGE` (7 dias)
- Se não marcado: `session.set_expiry(0)` — expira ao fechar o navegador

### Proteção de rotas
- `@login_required` redireciona para `/login/` com parâmetro `?next=<url_original>`
- Após login, o `next` é respeitado: o usuário vai para onde tentava acessar
- ONGs e resgatadores sem permissão no `/dashboard/ong/` são redirecionados

### Redirect por tipo de perfil
- Após login: adotante → `/dashboard/`, resgatador/ONG → `/dashboard/ong/`
- Implementado em `_redirect_por_perfil(user)` nas views

### Formulário de cadastro
- Campos de ONG são mostrados/escondidos via JavaScript no template
- Validação server-side garante `nome_organizacao` para tipo ONG
- `save()` do form usa `set_password()` para fazer hash da senha corretamente

---

## 🔗 Integração com o restante do projeto

Para integrar com as outras telas HTML (listagem, detalhe, aprovação):

1. Copie o app `accounts/` para dentro do seu projeto Django existente
2. Adicione `'accounts'` em `INSTALLED_APPS`
3. Inclua as URLs: `path('', include('accounts.urls'))`
4. Defina `AUTH_USER_MODEL = 'accounts.UsuarioPetConect'` no `settings.py`
5. Execute `makemigrations` e `migrate`
